export class BusSchedule {
    route: string;
    depart: any;
    arrive: any;
}